let targetElemt = null;
// used to send/recive message with in extension
let receiver = (message, sender, sendResponse) => {
    if (message.type === "getXPath") {
        parseDOM(targetElemt);
    }
};
chrome.runtime.onMessage.addListener(receiver);

// capture mouse events once the DOM is loaded
window.addEventListener('DOMContentLoaded', (event) => {
    init();
});

// get the target element once click on the context menu
function init() {
    console.log("Init block");
    document.addEventListener("mousedown", (event) => {
        targetElemt = event.target;
    }, false);
}

// store all the XPath values in an array
let XPATHDATAZCQA = [];


// find different patterns of XPath 
function parseDOM(targetElemt) {
    XPATHDATAZCQA = [];
    let tag = targetElemt.tagName.toLowerCase();
    let attributes = targetElemt.attributes;
    console.log(attributes);

    addAllXPathAttributes(attributes, tag, targetElemt);
    getTextXPath(targetElemt);
    //--- console.log("XPATHDATAZCQA=>"+XPATHDATAZCQA); 
    let message = {
        request: "sendtodevtools",
        xpath: XPATHDATAZCQA
    }
  //  chrome.runtime.sendMessage(message)
  //---  console.log(`message.xpath ${message.xpath}`);
    localStorage.clear();
    localStorage.setItem('datazcqaLocatorsstored', XPATHDATAZCQA);
  //---  console.log(message.xpath);
    chrome.runtime.sendMessage(message)
   // XPATHDATAZCQA = [];
}

// get all attribtes based XPath
function addAllXPathAttributes(attributes, tagName, targetElemt) {
   // console.log(`clicked tagName is ${tagName}`)
   // console.log(Array.prototype.slice.call(attributes));
    Array.prototype.slice.call(attributes).forEach(element => {
        if(element.name==="id"||element.name==="name"||element.name==="class"||element.name==="data-zcqa"){

            switch (element.name) {
                case "id":
                    getUniqueId(targetElemt, tagName);
                    break;
                case "name":
                    getUniqueName(targetElemt, tagName);
                    break;
               // case "className":
               case "class":
                    getUniqueClassName(targetElemt, tagName);
                    break;
                default:
                    if (element.value != '')
                        attributesBasedXPath(element, tagName);
                    break;
            }

        }
        
    });
}

// find the no.of elements matches with XPath
function getCountOfXPath(xpath) {
    let count = document.evaluate(
        `count(${xpath})`, document, null, XPathResult.ANY_TYPE, null
    ).numberValue;
    console.log(`count of ${xpath} is ${count}`);
    return count;
}



// id
function getUniqueId(elemet, tag) {
    let idValue = elemet.id;
    let idPattern = `//*[@id='${idValue}']`;
    let count = getCountOfXPath(idPattern);
    if (count == 1) {
       XPATHDATAZCQA.push(["->unique id:", idPattern]);
    }
}

// name
function getUniqueName(element, tag) {
    let value = element.name;
    let nameValue = `//*[@name='${value}']`;
    let count = getCountOfXPath(nameValue);
    if (count == 1) {
       XPATHDATAZCQA.push(["->unique name:", nameValue]);
    }
}

// className
function getUniqueClassName(element, tag) {
    let value = element.className;
    let classvalue = `//*[@class='${value}']`;
    let count = getCountOfXPath(classvalue);
    if (count == 1) {
        XPATHDATAZCQA.push(["->className:", classvalue]);
    }
}

// data-zcqa
/*function getUniqueDataZcqa(element, tag) {
    let value = element;
    let classvalue = `//*[@data-zcqa='${value}']`;
    let count = getCountOfXPath(classvalue);
    if (count == 1) {
        XPATHDATA.push(["->Data-Zcqa:", value]);
    }
}*/


// tag
function getUniqueTagName(element, tag) {
    let count = document.getElementsByTagName(tag).length;
    if (count == 1) {
        XPATHDATAZCQA.push(["->unique Tag name:", tag]);
    }
}
// link
function getUniqueLinkText(ele, tag) {
}


// Attributes based XPath 
function attributesBasedXPath(element, tagName) {
    let temp = `//${tagName}[@${element.name}='${element.value}']`;
    let count = getCountOfXPath(temp);
    if (count == 1) {
        XPATHDATAZCQA.push(["->attributes based Xpath:", temp]);
    }
  
}



