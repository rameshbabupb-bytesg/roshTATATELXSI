var indextwo=require('./indextwo.js')
var xpath="->unique id:,//*[@id='moreTools'],->attributes based Xpath:,//span[@data-zcqa='cv_tools'],->attributes based Xpath:,//span[@class='normalDropDown pR vat'],->text,//span[text()=' Actions ']";
console.log(xpath);
// var xp=xpath.split('->');
// console.log(xp);
// for(let i=1;i<xp.length;i++)
// {
// console.log( xp[i].split(",")[1] );
// }

// var h=["abc","defg","hij"]
// console.log(h)
// console.log(typeof(h))
// var m=h;
// console.log(m)

// var check=[]
// check.push(["hai","h"])
// check.push(["hai","h"])
// console.log(check)
// console.log(typeof(check))


// console.log(h[0].substring(0,2))


