
console.log(`From Panel.js`);
var stackedLocators="";
var locatorsStackedCount=0;
chrome.runtime.onMessage.addListener((req, rec, res) => {
    if (req.request === "sendtodevtools") {
        console.log(`xpaths: ${req.xpath}`);
        var allLocators=req.xpath;
        
        var result="";
        var datazcqaonly="";
        var locatorObjName="locatorObjName";
        var locatorDescription="locatorDescription";
        var tagName="";
        var locatorValue="";
        var isDataZcqaPresent=false;
        for(let i=0;i<allLocators.length;i++){
          if((allLocators[i][1]).includes("data-zcqa")){
            isDataZcqaPresent=true;
            console.log(`isDataZcqaPresent ${isDataZcqaPresent}`)
            break;
          }
        } 
       
        for(let i=0;i<allLocators.length;i++){
            if((allLocators[i][1]).includes("data-zcqa")||(allLocators[i][1]).includes("id") || (allLocators[i][1]).includes("class"))
            {
                   let temp=allLocators[i][1].split("@");
                   let  csspath=temp[1].substring(0,(temp[1].length));

                   tagName=temp[0].substring(2, (temp[0].length)-1);
                   if(tagName==="*"){
                    tagName="loc";
                   }
                   if( (!isDataZcqaPresent) &&  ( (allLocators[i][1]).includes("id")  ) ){
                     
                    locatorValue=temp[1].substring ( temp[1].indexOf('\'')+1 , temp[1].lastIndexOf('\'') )
                    locatorObjName=tagName+"_"+locatorValue;
                    locatorDescription=tagName+"_"+locatorValue;
                   }
                   else if( (allLocators[i][1]).includes("data-zcqa")  ){
                    locatorValue=temp[1].substring ( temp[1].indexOf('\'')+1 , temp[1].lastIndexOf('\'') )
                    locatorObjName=tagName+"_"+locatorValue;
                    locatorDescription=tagName+"_"+locatorValue;
                   }
                    
                   if(locatorObjName.includes("-")){
                    locatorObjName=locatorObjName.replaceAll("-","_");
                   }


                    if((allLocators[i][1]).includes("data-zcqa"))
                    {
                     datazcqaonly+="<div  id=datazcqa"+i+"><p class='locatortobeCopy' title='Click To Copy'>"+`Locator ${locatorObjName}=new Locator(By.cssSelector("[${csspath}"),"${locatorDescription}");`+"</p></div>"
                    }else{
                     result+="<div id=cssselector"+i+"><p class='locatortobeCopy' title='Click To Copy'>"+`Locator ${locatorObjName}=new Locator(By.cssSelector("[${csspath}"),"${locatorDescription}");`+"</p></div>"
                    }
              }
           
               result+="<div id=xpath"+i+"><p class='locatortobeCopy' title='Click To Copy'>"+`Locator ${locatorObjName}=new Locator(By.xpath("${allLocators[i][1]}"),"${locatorDescription}");`+"</p></div>"
        }
        result=result.replaceAll("locatorObjName",locatorObjName).replaceAll("locatorDescription",locatorDescription);
       
        console.log(`result is ${result}`)
        console.log(`Data-Zcqa only is ${datazcqaonly}`)
        document.getElementById("display").innerHTML=result;
        if(datazcqaonly===""&&result===""){
          datazcqaonly="No Unique Locators"
        }
        document.getElementById("displaydatazcqa").innerHTML=datazcqaonly;
        document.getElementById("display").innerHTML=result;
       //--- document.getElementById("display").innerHTML=allLocators;
       //--- buildUI(req.xpath);

       var elements=document.getElementsByClassName('locatortobeCopy');
       var myFunction =function()
       {
           var copiedText=this.innerText;
           console.log(`copiedText ${copiedText}`)
         // copyToClipboard(copiedText);
         // showSnackBar();
            if(!stackedLocators.includes(copiedText))
            {
              stackedLocators+=copiedText+"\n";
              locatorsStackedCount++;
            }
            copyToClipboard(stackedLocators);
            showCopiedMsg(this);
            console.log(`locatorsStackedCount${locatorsStackedCount}`);
            document.getElementById("locsCount").innerText=locatorsStackedCount;
            if(locatorsStackedCount>0)
            {
              document.getElementById("locsCount").style.visibility="visible";
            }
       };
       for (var i = 0; i < elements.length; i++) {
             elements[i].addEventListener('click', myFunction, false);
       }     
       document.getElementById("clearTrash").addEventListener("click", clearStack);
      
    }
})


const copyToClipboard = text => {
  const fake = prepareFake(text);
  const result = copyText();
  document.body.removeChild(fake);
  return result;
};


const prepareFake = text => {
  const fakeEl = document.createElement('textarea');
  fakeEl.style.fontSize = '12pt';
  fakeEl.style.border = '0';
  fakeEl.style.padding = '0';
  fakeEl.style.margin = '0';
  fakeEl.style.position = 'absolute';
  fakeEl.setAttribute('readonly', '');

  fakeEl.value = text;
  document.body.appendChild(fakeEl);

  fakeEl.focus();
  fakeEl.setSelectionRange(0, fakeEl.value.length);

  return fakeEl;
};
const copyText = () => {
  let result;
  try {
    result = document.execCommand('copy');
  } catch (e) {
    result = false;
  }
  return result;
};

/*function showSnackBar() {
  var sb = document.getElementById("snackbar");
  //this is where the class name will be added & removed to activate the css
  sb.className = "show";
  setTimeout(()=>{ sb.className = sb.className.replace("show", ""); }, 1000);
}*/

   
function showCopiedMsg(obj){
  obj.parentNode.className="copied";
  setTimeout(()=>{  obj.parentNode.className =  obj.parentNode.className.replace("copied", ""); }, 800);
}




function clearStack(){
  console.log("clearStack")
  stackedLocators=" ";locatorsStackedCount=0;
  copyToClipboard(stackedLocators);
  stackedLocators="";
  let locCountBadge=document.getElementById("locsCount");
  locCountBadge.innerText=locatorsStackedCount;
  locCountBadge.style.visibility="hidden";
}