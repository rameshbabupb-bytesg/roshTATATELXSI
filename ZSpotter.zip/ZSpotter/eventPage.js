let installURL = "https://crm.zoho.com";
let updateURL = "https://developer.chrome.com/docs/extensions/mv3/messaging/";
let uninstallURL = "https://crm.zoho.com";

chrome.runtime.setUninstallURL(uninstallURL, () => { });


let installReason = (detail) => {
    console.log("DeTail=>"+detail);

    if (detail.reason === "install") {
        chrome.tabs.create({
            url: installURL
        })
    } else if (detail.reason === "update") {
        notification();
        chrome.notifications.onClicked.addListener(onClickNotification);
    }
}


function onClickNotification() {
    chrome.tabs.create({
        url: updateURL
    });
}

function notification() {
    chrome.notifications.create('DATAZCQA_ID',
        {
            title: 'ZSpotter',
            message: 'ZSpotter updated!!!',
            iconUrl: 'assets/ZspotterImageg.png',
            type: 'basic',
            eventTime: Date.now()
        }
    )
}


chrome.runtime.onInstalled.addListener((details) => {
    installReason(details)
   
})


chrome.contextMenus.create({
    "id": "zspotter_id",
    "title": "Get Locators",
    "contexts": ["all"]
})
let getXPath = (info, tab) => {
    let msg = {
        type: 'getXPath'
    }
    chrome.tabs.sendMessage(tab.id, msg, () => {
        console.log(`Message sent (on Time is ${new Date()} ) `);
    })
    console.log(tab);
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
    getXPath(info, tab)
    console.log("***Context menu clicked***");
})



//VERSION 2
chrome.browserAction.onClicked.addListener(function(tab) {
    // No tabs or host permissions needed!
    //console.log('Turning ' + tab.url + ' red!');
  
    console.log("colsnl");
    chrome.tabs.executeScript({
      code: 'document.querySelectorAll("[data-zcqa]").forEach(function(a){a.setAttribute("style", "border: 3px solid green !important;")})'
    });
  });

  //VERSION 3
/*  chrome.action.onClicked.addListener(function(tab) {
  let tab = await getCurrentTab();
  
  chrome.scripting.executeScript({
    code: 'document.querySelectorAll("[data-zcqa]").forEach(function(a){a.setAttribute("style", "border: 3px solid green !important;")})'
  });
});
*/